/***************************************************************************//**
 *   @file   main.c
********************************************************************************
 * Copyright 2013(c) Analog Devices, Inc.
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *  - Neither the name of Analog Devices, Inc. nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *  - The use of this software may or may not infringe the patent rights
 *    of one or more patent holders.  This license does not release you
 *    from the requirement that you obtain separate licenses from these
 *    patent holders to use this software.
 *  - Use of the software either in source or binary form, must be run
 *    on or directly connected to an Analog Devices Inc. component.
 *
 * THIS SOFTWARE IS PROVIDED BY ANALOG DEVICES "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, NON-INFRINGEMENT,
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL ANALOG DEVICES BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, INTELLECTUAL PROPERTY RIGHTS, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
********************************************************************************
 *   SVN Revision: $WCREV$
*******************************************************************************/

/******************************************************************************/
/***************************** Include Files **********************************/
/******************************************************************************/
#include <stdio.h>
#include "xil_cache.h"
#include "xbasic_types.h"
#include "xil_io.h"
#include "cf_hdmi.h"
#include "atv_platform.h"
#include "transmitter.h"
#include "xil_exception.h"
#include "xuartps.h"
#include "sleep.h"
#include "puzzle_demo.h"
#include "time.h"
#include "distance_ip.h"

//#include "cf_hdmi_demo.h"

void fillScreen(void);
void backupIMG_DATA(void);
void pictureCut(void);
void updownleftright(void);
void PatternChanged(void);
extern void delay_ms(u32 ms_count);
extern char inbyte(void);
extern u32 IMG_DATA[];
extern u32 IMG_DATA_bak[];
extern u32 BLANK_DATA[];
extern u32 PUZZLE_DATA[9][PUZZLE_LENGTH];
u32 PUZZLE_DATA_BAK[9][PUZZLE_LENGTH];
//u32 number[9]={5,1,0,4,2,3,6,7,8};
u32 number[9]={0,1,2,3,4,5,6,7,8};
u32 location;
u32 direction;
u32 move_trigger;
u32 count;
u32 down_sig;
int sensor[4][4];

#define LEFT	00
#define RIGHT 	01
#define UP 		02
#define DOWN	03
#define STAND	04
#define UPLEFT  	00
#define UPRIGHT  	04
#define DOWNLEFT  	08
#define DOWNRIGHT  	12
#define BUTTONLEFT	28
#define BUTTONRIGHT	24
#define BUTTONUP	20
#define BUTTONDOWN	16
#define PRESSDOWN	32
/******************************************************************************/
/************************** Macros Definitions ********************************/
/******************************************************************************/
#define HDMI_CALL_INTERVAL_MS	10			/* Interval between two         */
											/* iterations of the main loop  */
#define DBG_MSG                 xil_printf

/******************************************************************************/
/************************ Variables Definitions *******************************/
/******************************************************************************/
static UCHAR    MajorRev;      /* Major Release Number */
static UCHAR    MinorRev;      /* Usually used for code-drops */
static UCHAR    RcRev;         /* Release Candidate Number */
static BOOL     DriverEnable;
static BOOL     LastEnable;

/***************************************************************************//**
 * @brief Enables the driver.
 *
 * @return Returns ATVERR_OK.
*******************************************************************************/
void APP_EnableDriver (BOOL Enable)
{
    DriverEnable = Enable;
}

/*************************************************************+**************//**
 * @brief Returns the driver enable status.
 *
 * @return Returns the driver enable status.
*******************************************************************************/
static BOOL APP_DriverEnabled (void)
{
    if ((DriverEnable && HAL_GetMBSwitchState()) != LastEnable)
    {
        LastEnable = DriverEnable && HAL_GetMBSwitchState();
        DBG_MSG ("APP: Driver %s\n\r", LastEnable? "Enabled": "Disabled");
    }
    return (LastEnable);
}

/***************************************************************************//**
 * @brief Displays the application version and the chip revision.
 *
 * @return None.
*******************************************************************************/
static void APP_PrintRevisions (void)
{
	UINT16 TxRev;

	ADIAPI_TxGetChipRevision(&TxRev);

	DBG_MSG("\n\r********************************************************************\r\n");
	DBG_MSG("  ADI HDMI Trasmitter Application Ver R%d.%d.%d\n\r", MajorRev, MinorRev, RcRev);
	DBG_MSG("  HDMI-TX:  ADV7511 Rev 0x%x\r\n", TxRev);
	DBG_MSG("  Created:  %s At %s\n\r", __DATE__, __TIME__);
	DBG_MSG("********************************************************************\r\n\n\r");
}

/***************************************************************************//**
 * @brief Changes the video resolution.
 *
 * @return None.
*******************************************************************************/
static void APP_ChangeResolution (void)
{
	char *resolutions[7] = {"640x480", "800x600", "1024x768", "1280x720", "1360x768", "1600x900", "1920x1080"};
	char receivedChar    = 0;

	if(XUartPs_IsReceiveData(UART_BASEADDR))
	{
		receivedChar = inbyte();
		if((receivedChar >= 0x30) && (receivedChar <= 0x36))
		{
			SetVideoResolution(receivedChar - 0x30);
			DBG_MSG("Resolution was changed to %s \r\n", resolutions[receivedChar - 0x30]);
		}
		else
		{
			if((receivedChar != 0x0A) && (receivedChar != 0x0D))
			{
				SetVideoResolution(RESOLUTION_640x480);
				DBG_MSG("Resolution was changed to %s \r\n", resolutions[0]);
			}
		}
	}
}

/***************************************************************************//**
 * @brief Main function.
 *
 * @return Returns 0.
*******************************************************************************/
int main()
{
	UINT32 StartCount;

	MajorRev     = 1;
	MinorRev     = 1;
	RcRev        = 1;
	DriverEnable = TRUE;
	LastEnable   = FALSE;

	Xil_ICacheEnable();
	Xil_DCacheEnable();
	backupIMG_DATA();
////
///	u32 i;
///	u32 count;
///	count=0;

#ifdef XPAR_AXI_IIC_0_BASEADDR
	HAL_PlatformInit(XPAR_AXI_IIC_0_BASEADDR,	/* Perform any required platform init */
					 XPAR_SCUTIMER_DEVICE_ID,	/* including hardware reset to HDMI devices */
					 XPAR_SCUGIC_SINGLE_DEVICE_ID,
					 XPAR_SCUTIMER_INTR);
#else
	HAL_PlatformInit(XPAR_AXI_IIC_MAIN_BASEADDR,	/* Perform any required platform init */
					 XPAR_SCUTIMER_DEVICE_ID,	/* including hardware reset to HDMI devices */
					 XPAR_SCUGIC_SINGLE_DEVICE_ID,
					 XPAR_SCUTIMER_INTR);
#endif

	Xil_ExceptionEnable();

	SetVideoResolution(RESOLUTION_640x480);
	InitHdmiAudioPcore();

	APP_PrintRevisions();       /* Display S/W and H/W revisions */

	DBG_MSG("To change the video resolution press:\r\n");
	DBG_MSG("  '0' - 640x480;  '1' - 800x600;  '2' - 1024x768; '3' - 1280x720 \r\n");
	DBG_MSG("  '4' - 1360x768; '5' - 1600x900; '6' - 1920x1080.\r\n");

	ADIAPI_TransmitterInit();   /* Initialize ADI repeater software and h/w */

	ADIAPI_TransmitterSetPowerMode(REP_POWER_UP);

	StartCount = HAL_GetCurrentMsCount();

	location=8;
	pictureCut();
	if (ATV_GetElapsedMs (StartCount, NULL) >= HDMI_CALL_INTERVAL_MS)
	{
		StartCount = HAL_GetCurrentMsCount();
		if (APP_DriverEnabled())
		{
			ADIAPI_TransmitterMain();
		}
	}
	SetVideoChangePic(RESOLUTION_640x480);
	while(1)
	{
		if (ATV_GetElapsedMs (StartCount, NULL) >= HDMI_CALL_INTERVAL_MS)
			{
				StartCount = HAL_GetCurrentMsCount();
				if (APP_DriverEnabled())
				{
					ADIAPI_TransmitterMain();
				}
			}
			SetVideoChangePic(RESOLUTION_640x480);
		//SetVideoChangePic(RESOLUTION_640x480);
		///
		while(1){
			down_sig=DISTANCE_IP_mReadReg(XPAR_DISTANCE_IP_0_S00_AXI_BASEADDR, PRESSDOWN);
			if(down_sig){
				move_trigger=down_sig;
				direction=DISTANCE_IP_mReadReg(XPAR_DISTANCE_IP_0_S00_AXI_BASEADDR, BUTTONLEFT)*0+\
								DISTANCE_IP_mReadReg(XPAR_DISTANCE_IP_0_S00_AXI_BASEADDR, BUTTONRIGHT)*1+\
								DISTANCE_IP_mReadReg(XPAR_DISTANCE_IP_0_S00_AXI_BASEADDR, BUTTONUP)*2+\
								DISTANCE_IP_mReadReg(XPAR_DISTANCE_IP_0_S00_AXI_BASEADDR, BUTTONDOWN)*3;
				break;}
			if(DISTANCE_IP_mReadReg(XPAR_DISTANCE_IP_0_S00_AXI_BASEADDR,0)<100 \
			    &&DISTANCE_IP_mReadReg(XPAR_DISTANCE_IP_0_S00_AXI_BASEADDR,4)<100\
				&&DISTANCE_IP_mReadReg(XPAR_DISTANCE_IP_0_S00_AXI_BASEADDR,8)<100\
			 &&DISTANCE_IP_mReadReg(XPAR_DISTANCE_IP_0_S00_AXI_BASEADDR,12)<100)
			{
				print("break\n");
				sensor_read();
			    direction=direction_judge();
			    if(direction<STAND){
			    	printf("direction is %d\n,",direction);
			    	move_trigger=1;
			    	break;}
			}
		}
		updownleftright();
		PatternChanged();
		fillScreen();
		//pictureCut();
		SetVideoChangePic(RESOLUTION_640x480);
		//DBG_MSG("changed\r\n");
		//APP_ChangeResolution();
		count++;
		sleep(1);
	}

	Xil_DCacheDisable();
	Xil_ICacheDisable();

	return(0);
}

///function change direction
void pictureCut(void){
	u32 i,j;
//	u32 black;
//	u32 col,line;
	///change the order
	u32 tmp;
	u32 m;
	for (i=0;i<7;i++){
		srand(count);
		m=rand()%8;
		tmp=number[m];
		number[m]=number[i];
		number[i]=tmp;
	}
	for (i=0;i<9;i++){
		if(i!=location){
		for (j=0;j<PUZZLE_LENGTH;j++){
			PUZZLE_DATA[i][j]=PUZZLE_DATA_BAK[number[i]][j];
		}
		}
		else {
			for (j=0;j<PUZZLE_LENGTH;j++){
							PUZZLE_DATA[location][j]=0x1000000;
						}
		}
	}
	fillScreen();
	print("done\n");
}
//backup IMG_DATA
void backupIMG_DATA(void){
	u32 i,j;
	for(i=0;i<9;i++){
		for(j=0;j<PUZZLE_LENGTH;j++){
			PUZZLE_DATA_BAK[i][j]=PUZZLE_DATA[i][j];
		}
	}
}

//change
void updownleftright(void){
	u32 location_tmp;
	u32 num_tmp;
	if(move_trigger){
		switch(direction){
		case UP:if(location>=3){location_tmp=location; location=location-3;}else location_tmp=location; break;
		case DOWN:if(location<6){location_tmp=location; location=location+3;}else location_tmp=location; break;
		case LEFT:if(location%3!=0){location_tmp=location;location=location-1;}else location_tmp=location; break;
		case RIGHT:if(location%3!=2){location_tmp=location;location=location+1;}else location_tmp=location; break;
		case STAND:location_tmp=location; break;
		default:location_tmp=location; break;
		}
	}
	move_trigger=0;
	direction=STAND;
	num_tmp=number[location_tmp];
	number[location_tmp]=number[location];
	number[location]=num_tmp;
}
void PatternChanged(void){
	u32 i,j;
	for (i=0;i<9;i++){
		if(i!=location){
		for (j=0;j<PUZZLE_LENGTH;j++){
			PUZZLE_DATA[i][j]=PUZZLE_DATA_BAK[number[i]][j];
		}}
		else {
			for (j=0;j<PUZZLE_LENGTH;j++){
			PUZZLE_DATA[location][j]=0x1000000;}
		}
	}
}

void fillScreen(void){
	u32 i,j,k;
	u32 col,line;
	for(i=0;i<80;i++){
			for (j=0;j<480;j++)
			{
				IMG_DATA[j*640+i]=BLANK_DATA[i*480+j];
				IMG_DATA[j*640+639-i]=BLANK_DATA[i*480+j];
			}
		}
		for (i=0;i<9;i++){
			col=i%3;
			line=i/3;
			for(j=0;j<160;j++){
				for (k=0;k<160;k++){
					IMG_DATA[640*(line*160+j)+160*col+k+80]=PUZZLE_DATA[i][160*j+k];
				}
			}
		}
}

void sensor_read(void){
//	int i ;
//	for(i=0;i<4;i++){
//		sensor[0][4-i]=sensor[0][3-i];
//		sensor[1][4-i]=sensor[1][3-i];
//		sensor[2][4-i]=sensor[2][3-i];
//		sensor[3][4-i]=sensor[3][3-i];
//		usleep(200000);
//	}
	sensor[0][2]=sensor[0][1];
	sensor[1][2]=sensor[1][1];
	sensor[2][2]=sensor[2][1];
	sensor[3][2]=sensor[3][1];
	usleep(125000);
	sensor[0][1]=sensor[0][0];
	sensor[1][1]=sensor[1][0];
	sensor[2][1]=sensor[2][0];
	sensor[3][1]=sensor[3][0];
	usleep(125000);
	sensor[0][0]=DISTANCE_IP_mReadReg(XPAR_DISTANCE_IP_0_S00_AXI_BASEADDR,0);
	sensor[1][0]=DISTANCE_IP_mReadReg(XPAR_DISTANCE_IP_0_S00_AXI_BASEADDR,4);
	sensor[2][0]=DISTANCE_IP_mReadReg(XPAR_DISTANCE_IP_0_S00_AXI_BASEADDR,8);
	sensor[3][0]=DISTANCE_IP_mReadReg(XPAR_DISTANCE_IP_0_S00_AXI_BASEADDR,12);
}

int direction_judge(void){
//	int direction;

		 if(sensor[0][1]<sensor[1][1]&&sensor[3][1]<sensor[2][1]&& \
			sensor[0][0]>sensor[1][0]&&sensor[3][0]>sensor[2][0]
			//sensor[0][2]>sensor[1][2]&&sensor[3][2]>sensor[2][2]

//			sensor[0][2]<sensor[0][1]&&sensor[1][2]>sensor[1][1]&& \
			sensor[2][2]>sensor[2][1]&&sensor[3][2]<sensor[3][1]
															  )
	{
		return LEFT;
		//return RIGHT;
	}
	else if(sensor[0][1]>sensor[1][1]&&sensor[3][1]>sensor[2][1]&& \
			sensor[0][0]<sensor[1][0]&&sensor[3][0]<sensor[2][0]
			//sensor[0][2]<sensor[1][2]&&sensor[3][2]<sensor[2][2]
//			sensor[0][2]>sensor[0][1]&&sensor[1][2]<sensor[1][1]&& \
			sensor[2][2]<sensor[2][1]&&sensor[3][2]>sensor[3][1]
															  ){
		return RIGHT;
		//return LEFT;
	}
	else if(sensor[0][1]>sensor[3][1]&&sensor[1][1]>sensor[2][1]&& \
			sensor[0][0]<sensor[3][0]&&sensor[1][0]<sensor[2][0]
		//	sensor[0][2]<sensor[3][2]&&sensor[1][2]<sensor[2][2]
//			sensor[0][2]<sensor[0][1]&&sensor[1][2]<sensor[1][1]&& \
			sensor[2][2]>sensor[2][1]&&sensor[3][2]>sensor[3][1]
															  ){
		return UP;
	}
	else if(sensor[0][1]<sensor[3][1]&&sensor[1][1]<sensor[2][1]&& \
			sensor[0][0]>sensor[2][0]&&sensor[1][0]>sensor[2][0]
		//	sensor[0][2]>sensor[2][2]&&sensor[1][2]>sensor[2][2]
//			sensor[0][2]>sensor[0][1]&&sensor[1][2]>sensor[1][1]&& \
			sensor[2][2]<sensor[2][1]&&sensor[3][2]<sensor[3][1]
															  ){
		return DOWN;
	}
	else {
		return STAND;
	}

}
